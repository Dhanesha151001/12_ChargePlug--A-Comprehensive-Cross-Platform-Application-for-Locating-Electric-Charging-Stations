class GradleException {
    GradleException() {
    }
}

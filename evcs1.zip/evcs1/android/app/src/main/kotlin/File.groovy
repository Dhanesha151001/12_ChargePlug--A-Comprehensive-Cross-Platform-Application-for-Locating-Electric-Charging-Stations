class File {
    File(def p, java.lang.String p) {
    }
}

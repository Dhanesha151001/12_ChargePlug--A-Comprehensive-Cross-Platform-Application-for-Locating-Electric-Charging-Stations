package com.example.evcs1

//import io.flutter.reference.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

open class FlutterActivity {

}

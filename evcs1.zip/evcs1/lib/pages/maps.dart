import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';


class Maps extends StatefulWidget {
  const Maps({Key? key, required String title}) : super(key: key);

  @override
  State<Maps> createState() => _MapsState();
}

class _MapsState extends State<Maps> {

  final Completer<GoogleMapController> _controller = Completer();
  static const CameraPosition initialPosition = CameraPosition(target: LatLng(19.2680, 72.9672), zoom: 14.0);


  final List<Marker> _markers = <Marker> [];
  final List<Marker> _list = const[
    Marker(
        markerId: MarkerId('2'),
        position: LatLng(19.257101, 72.971943),
        infoWindow: InfoWindow(
            title: 'Tata Charging Station'
        )
    ),
    Marker(
        markerId: MarkerId('3'),
        position: LatLng(19.223827, 72.977805),
        infoWindow: InfoWindow(
            title: 'EV Charging Store'
        )
    ),
    Marker(
        markerId: MarkerId('4'),
        position: LatLng(19.232473, 72.975621),
        infoWindow: InfoWindow(
            title: 'Fortum Charging Station'
        )
    ),
    Marker(
        markerId: MarkerId('5'),
        position: LatLng(19.270925, 72.96545),
        infoWindow: InfoWindow(
            title: 'Powerbank Charging Station'
        )
    ),
    Marker(
        markerId: MarkerId('6'),
        position: LatLng(19.256941, 72.984551),
        infoWindow: InfoWindow(
            title: 'Electric Vehicle Charging Station'
        )
    ),
    Marker(
        markerId: MarkerId('7'),
        position: LatLng(19.234157, 72.976021),
        infoWindow: InfoWindow(
            title: 'Ather Charging Station'
        )
    ),
    Marker(
        markerId: MarkerId('8'),
        position: LatLng(19.220321, 72.974835),
        infoWindow: InfoWindow(
            title: 'Ev-Chargify'
        )
    ),

  ];

  loadData(){
    Maps().then((value) async {
      print('my current Location');
      print(value.latitude.toString() + "" + value.longitude.toString());

      _markers.add(
          Marker(
              markerId: MarkerId("1"),
              position:LatLng(value.latitude,value.longitude),
              infoWindow: const InfoWindow(
                  title: 'My current Location'
              )
          )
      );
      CameraPosition cameraPosition = CameraPosition(
          zoom: 17,
          target: LatLng(value.latitude,value.longitude));
      final GoogleMapController controller = await _controller.future;
      controller.animateCamera(CameraUpdate.newCameraPosition(cameraPosition));
      setState(() {

      });
    });
  }

  Future<Position> Maps() async{
    await Geolocator.requestPermission().then((value){

    }).onError((error, stackTrace) {
      print("error"+ error.toString());
    });

    return await Geolocator.getCurrentPosition();

  }

  @override
  void initState(){
    super.initState();
    loadData();
    _markers.addAll(_list);
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Maps"),centerTitle: true,elevation: 0,),
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      body: GoogleMap(
        initialCameraPosition: initialPosition,
        mapType: MapType.normal,
        markers: Set<Marker>.of(_markers),
        onMapCreated: (GoogleMapController controller) {
          _controller.complete(controller);
        },
      ),
      floatingActionButton: FloatingActionButton(
          onPressed: (){
            Maps().then((value) async {
              print('my current Location');
              print(value.latitude.toString() + "" + value.longitude.toString());

              _markers.add(
                  Marker(
                      markerId: MarkerId("1"),
                      position:LatLng(value.latitude,value.longitude),
                      infoWindow: const InfoWindow(
                          title: 'My current Location'
                      )
                  )
              );
              CameraPosition cameraPosition = CameraPosition(
                  target: LatLng(value.latitude,value.longitude),zoom: 14.0);
              final GoogleMapController controller = await _controller.future;
              controller.animateCamera(CameraUpdate.newCameraPosition(cameraPosition));
              setState(() {

              });

            });


          },
          child:const Icon(Icons.my_location_outlined)
      ),
    );
  }
}

